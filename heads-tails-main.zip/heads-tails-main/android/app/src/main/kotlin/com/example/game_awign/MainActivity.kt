package com.example.game_awign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
